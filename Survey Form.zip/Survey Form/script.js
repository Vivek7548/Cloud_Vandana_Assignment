// JavaScript code
document.getElementById("survey-form").addEventListener("submit", function(event) {
    event.preventDefault();

    // Get form values
    const Name = document.getElementById("Name").value;
    const email = document.getElementById("email").value;
    const satisfaction = document.querySelector('input[name="satisfaction"]:checked').value;
    const satisfaction2 = document.querySelector('input[name="satisfaction2"]:checked').value;
    const satisfaction3 = document.querySelector('input[name="satisfaction3"]:checked').value;

    const comments = document.getElementById("comments").value;

    // Display user details in modal
    const userDetailsModal = document.getElementById("userDetailsModal");
    const userDetailsBody = document.getElementById("userDetailsBody");
    userDetailsBody.innerHTML = `
        <p><strong>Name:</strong> ${Name}</p>
        <p><strong>Email:</strong> ${email}</p>
        <p><strong>Is this first time You are using our product & services?:</strong> ${satisfaction}</p>
        <p><strong>Would you suggestion to your friends and colleague?:</strong> ${satisfaction2}</p>
        <p><strong>How satisfied are you with our company?:</strong> ${satisfaction3}</p>

        <p><strong>Comments:</strong> ${comments}</p>
    `;
    $(userDetailsModal).modal("show"); // Show the modal

    // Reset the form after modal is closed
    $(userDetailsModal).on("hidden.bs.modal", function() {
        document.getElementById("survey-form").reset();
    });
});